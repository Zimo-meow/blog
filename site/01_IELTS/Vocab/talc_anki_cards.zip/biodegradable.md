START
问答题
正面: biodegradable
背面: 可生物降解的
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
