START
问答题
正面: trial
背面: 试验<br>test
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
