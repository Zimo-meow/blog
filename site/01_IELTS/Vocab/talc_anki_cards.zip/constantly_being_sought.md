START
问答题
正面: constantly being sought
背面: 持续被探索
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
