START
问答题
正面: extract
背面: 提取<br>derive; obtain
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
