START
问答题
正面: non‑reactive
背面: 化学惰性的<br>inert
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
