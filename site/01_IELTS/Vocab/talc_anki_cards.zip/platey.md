START
问答题
正面: platey
背面: 片状的<br>flaky; layered
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
