START
问答题
正面: wet‑table powder
背面: 可湿性粉剂
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
