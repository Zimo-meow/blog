START
问答题
正面: coat (v.)
背面: 覆盖；包覆<br>cover
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
