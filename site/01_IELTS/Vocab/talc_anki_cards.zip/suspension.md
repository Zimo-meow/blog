START
问答题
正面: suspension
背面: 悬浮液
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
