START
问答题
正面: long‑established
背面: 早已确立的<br>well‑established
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
