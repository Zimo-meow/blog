START
问答题
正面: commercial year
背面: 商业化年度
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
