START
问答题
正面: heat stress
背面: 热应激
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
