START
问答题
正面: chemically inert
背面: 化学惰性的<br>non-reactive
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
