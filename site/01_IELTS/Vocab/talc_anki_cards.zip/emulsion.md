START
问答题
正面: emulsion
背面: 乳状液
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
