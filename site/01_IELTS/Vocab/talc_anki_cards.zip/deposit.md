START
问答题
正面: deposit
背面: 矿床；沉积物<br>reserve; stockpile
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
