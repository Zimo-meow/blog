START
问答题
正面: talc
背面: 滑石<br>核心话题矿物
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
