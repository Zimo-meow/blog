START
问答题
正面: versatility
背面: 多功能性<br>adaptability; flexibility
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
