START
问答题
正面: dust (v.)
背面: 撒粉，喷粉<br>sprinkle
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
