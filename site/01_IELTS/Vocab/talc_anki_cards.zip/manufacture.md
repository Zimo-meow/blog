START
问答题
正面: manufacture
背面: 制造；生产<br>produce; make
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
