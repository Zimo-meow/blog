START
问答题
正面: boost
背面: 提高，增强<br>enhance; increase
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
