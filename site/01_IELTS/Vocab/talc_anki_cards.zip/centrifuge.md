START
问答题
正面: centrifuge
背面: 离心分离
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
