START
问答题
正面: stick (v.)
背面: 粘连<br>adhere; cling
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
