START
问答题
正面: hydrophobic
背面: 疏水的<br>water‑repellent
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
