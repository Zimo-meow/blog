START
问答题
正面: primary target
背面: 主要目标客户
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
