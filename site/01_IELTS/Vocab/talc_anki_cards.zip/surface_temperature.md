START
问答题
正面: surface temperature
背面: 表面温度
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
