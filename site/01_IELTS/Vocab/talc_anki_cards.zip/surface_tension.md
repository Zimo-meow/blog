START
问答题
正面: surface tension
背面: 表面张力
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
