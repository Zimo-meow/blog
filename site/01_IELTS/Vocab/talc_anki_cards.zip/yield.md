START
问答题
正面: yield
背面: 产量，出油率<br>output
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
