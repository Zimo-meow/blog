START
问答题
正面: emulsifier
背面: 乳化剂
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
