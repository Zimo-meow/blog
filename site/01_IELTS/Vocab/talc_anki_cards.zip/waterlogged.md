START
问答题
正面: waterlogged
背面: 积水的
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
