START
问答题
正面: sector
背面: 行业；领域
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
