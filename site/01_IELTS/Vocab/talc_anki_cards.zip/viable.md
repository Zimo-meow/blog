START
问答题
正面: viable
背面: 可行的<br>workable
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
