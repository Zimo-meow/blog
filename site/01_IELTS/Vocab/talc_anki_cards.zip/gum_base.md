START
问答题
正面: gum base
背面: 胶基(口香糖主要成分)
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
