START
问答题
正面: long‑term potential
背面: 长期潜力
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
