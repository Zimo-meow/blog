START
问答题
正面: incidence of sunburn
背面: 日灼发生率
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
