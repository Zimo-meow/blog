START
问答题
正面: canopy
背面: 覆盖层
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
