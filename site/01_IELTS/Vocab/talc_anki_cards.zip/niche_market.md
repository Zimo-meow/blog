START
问答题
正面: niche market
背面: 利基市场，小众市场<br>specialized segment
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
