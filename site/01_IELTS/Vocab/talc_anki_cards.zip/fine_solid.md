START
问答题
正面: fine solid
背面: 细颗粒固体
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
