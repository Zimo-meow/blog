START
问答题
正面: fruit‑crop protection
背面: 水果作物防护
END
TARGET DECK: 11408/IELTS::Vocab
FILE TAGS: #anki #ielts/vocab
